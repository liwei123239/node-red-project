import{o as e}from"./web-MPvN0pSp.js";import{bt as t,ft as n}from"./index-3-uZczqH.js";var r=e(),i=`
 ██████╗ ███████╗████████╗████████╗███████╗██████╗
 ██╔══██╗██╔════╝╚══██╔══╝╚══██╔══╝██╔════╝██╔══██╗
 ██████╔╝█████╗     ██║      ██║   █████╗  ██████╔╝
 ██╔══██╗██╔══╝     ██║      ██║   ██╔══╝  ██╔══██╗
 ██████╔╝███████╗   ██║      ██║   ███████╗██║  ██║
 ╚═════╝ ╚══════╝   ╚═╝      ╚═╝   ╚══════╝╚═╝  ╚═╝

 ████████╗    ███████╗████████╗ █████╗  ██████╗██╗  ██╗
 ╚══██╔══╝    ██╔════╝╚══██╔══╝██╔══██╗██╔════╝██║ ██╔╝
    ██║       ███████╗   ██║   ███████║██║     █████╔╝
    ██║       ╚════██║   ██║   ██╔══██║██║     ██╔═██╗
    ██║       ███████║   ██║   ██║  ██║╚██████╗██║  ██╗
    ╚═╝       ╚══════╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝
 `;function a(){let e=t(n.healthCheck.queryOptions());return(0,r.jsxs)(`div`,{className:`container mx-auto max-w-3xl px-4 py-2`,children:[(0,r.jsx)(`pre`,{className:`overflow-x-auto font-mono text-sm`,children:i}),(0,r.jsx)(`div`,{className:`grid gap-6`,children:(0,r.jsxs)(`section`,{className:`rounded-lg border p-4`,children:[(0,r.jsx)(`h2`,{className:`mb-2 font-medium`,children:`API Status`}),(0,r.jsxs)(`div`,{className:`flex items-center gap-2`,children:[(0,r.jsx)(`div`,{className:`h-2 w-2 rounded-full ${e.data?`bg-green-500`:`bg-red-500`}`}),(0,r.jsx)(`span`,{className:`text-sm text-muted-foreground`,children:e.isLoading?`Checking...`:e.data?`Connected`:`Disconnected`})]})]})})]})}export{a as component};